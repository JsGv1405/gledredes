$(document).ready(function(){

    
});

function update(){
    let id = document.getElementById("id").value;

    let year = document.getElementById("year").value;
    let mes = document.getElementById("mes").value;
    let semana = document.getElementById("semana").value;
    let fecha = document.getElementById("fecha").value;
    let objetivo = document.getElementById("objetivo").value;
    let herramienta = document.getElementById("herramienta").value;
    let colaboracion = document.getElementById("colaboracion").value;
    let redsocial = document.getElementById("redsocial").value;
    let post = document.getElementById("post").value;
    let contenido = document.getElementById("contenido").value;
    let linkblog = document.getElementById("linkblog").value;
    let linkrrss = document.getElementById("linkrrss").value;
    let linkweb = document.getElementById("linkweb").value;
    let linkform = document.getElementById("linkform").value;
    let linkyoutube = document.getElementById("linkyoutube").value;
    let arte = document.getElementById("arte").value;
    let comentario = document.getElementById("comentario").value;
    let responsable = document.getElementById("responsable").value;

    var cadena = "aux=update&year="+year+"&id="+id+"&mes="+mes+"&semana="+semana+"&fecha="+fecha+"&objetivo="+objetivo+"&herramienta="+herramienta+
    "&colaboracion="+colaboracion+"&redsocial="+redsocial+"&post="+post+"&contenido="+contenido+"&linkblog="+linkblog+"&linkrrss="+linkrrss+
    "&linkweb="+linkweb+"&linkform="+linkform+"&linkyoutube="+linkyoutube+"&arte="+arte+"&comentario="+comentario+"&responsable="+responsable;
    $.ajax({
        type: "POST",
        url: "controller/upperController.php",
        data: cadena,
        success: function (data) {
            if(data){
                success_noti("Datos Actualizados");
                window.location.href="index.php";
            }else{
                error_noti("Datos no Actualizados");
            }
            
            
        },
        error: function (e) {
            console.log(e);
            error_noti("Sistema no disponible");
        }
    });


}