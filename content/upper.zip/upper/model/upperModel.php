<?php

function consultarRedes($pais)
{
    include "../../../models/conection.php";
    $sqlBuscar = "SELECT * FROM dbcontenidoredesupper WHERE `pais`= '$pais'";
    $result = mysqli_query($conection, $sqlBuscar);
    return $result;
}

function search($id)
{
    include "../../../models/conection.php";
    $sqlBuscar = "SELECT * FROM `dbcontenidoredesupper` WHERE `id`= '$id';";
    $result = mysqli_query($conection, $sqlBuscar);

    if (mysqli_num_rows($result) > 0) {
        while($rowData = mysqli_fetch_array($result)){
              $val = $rowData["status"];
        }
        return $val;
    }else{
        return false;
    }
    
}

function aprobar($id,$comentario)
{
    include "../../../models/conection.php";
    $sqlUpdate = "UPDATE `dbcontenidoredesupper` SET `comentario`='$comentario', `status`='APROBADO' WHERE `id`='$id'";
    $result = mysqli_query($conection, $sqlUpdate);

    return $result;
}

function ejecutado($id)
{
    include "../../../models/conection.php";
    $sqlUpdate = "UPDATE `dbcontenidoredesupper` SET `status`='EJECUTADO' WHERE `id`='$id'";
    $result = mysqli_query($conection, $sqlUpdate);

    return $result;
}

function puntuacion($id,$alcance,$meGusta, $compartir , $puntuacion)
{
    include "../../../models/conection.php";
    $sqlUpdate = "UPDATE `dbcontenidoredesupper` SET `status`='EVALUADO' ,`alcance`='$alcance',`megusta`='$meGusta',`compartir`='$compartir', `puntuacion`='$puntuacion' WHERE `id`='$id'";
    $result = mysqli_query($conection, $sqlUpdate);

    return $result;
}

function update($id,$year, $mes, $semana, $fecha, $objetivo, $herramienta, $colaboracion, $redsocial, $post, $contenido, $linkblog
,$linkrrss, $linkweb, $linkform, $linkyoutube, $arte, $comentario, $responsable){

    include "../../../models/conection.php";
    $sqlUpdate = "UPDATE `dbcontenidoredesupper` SET `year`='$year',`mes`='$mes',`semana`='$semana',`fecha`='$fecha',
    `objetivo`='$objetivo',`herramienta`='$herramienta',`colaboracion`='$colaboracion',`post`='$post',`contenido`='$contenido',
    `redsocial`='$redsocial',`linkblog`='$linkblog',`linkrrss`='$linkrrss',`linkweb`='$linkweb',`linkform`='$linkform',
    `linkyoutube`='$linkyoutube',`arte`='$arte',`comentario`='$comentario',`responsable`='$responsable' WHERE `id` = '$id'";
    $result = mysqli_query($conection, $sqlUpdate);
    return $result;

}

/*

function checkFlujo($id,$comentarios){
    include "../../../model/conection.php";

    $sqlUpdate = "UPDATE `flujochile` SET `statusver`='1',`comentarios`='$comentarios' WHERE `id`='$id'";
    $result = mysqli_query($conection, $sqlUpdate);
    return $result;
}
*/

