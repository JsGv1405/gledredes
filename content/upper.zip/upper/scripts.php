<?php
date_default_timezone_set('America/Guayaquil');
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<link href="/css/style.css" rel="stylesheet" type="text/css"/>



<!--plugins-->
<link href="/gledredes/assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
<link href="/gledredes/assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
<!-- Bootstrap CSS -->
<link href="/gledredes/assets/css/bootstrap.min.css" rel="stylesheet" />
<link href="/gledredes/assets/css/bootstrap-extended.css" rel="stylesheet" />
<link href="/gledredes/assets/css/style.css" rel="stylesheet" />
<link href="/gledredes/assets/css/icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

<!-- loader-->
<link href="/gledredes/assets/css/pace.min.css" rel="stylesheet" />

<!--Theme Styles-->
<link href="/gledredes/assets/css/dark-theme.css" rel="stylesheet" />
<link href="/gledredes/assets/css/light-theme.css" rel="stylesheet" />
<link href="/gledredes/assets/css/semi-dark.css" rel="stylesheet" />
<link href="/gledredes/assets/css/header-colors.css" rel="stylesheet" />


<!--select-->
<link href="/gledredes/assets/plugins/select2/css/select2.min.css" rel="stylesheet" />
<link href="/gledredes/assets/plugins/select2/css/select2-bootstrap4.css" rel="stylesheet" />

<!--Iconos -->


<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">


<!--Datatables-->

<link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
<link rel="" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
<link rel="" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="" href="https://cdn.datatables.net/buttons/1.6.5/css/buttons.dataTables.min.css">

<!--Notificaiones-->
<link rel="stylesheet" href="/gledredes/assets/plugins/notifications/css/lobibox.min.css" />

<!--Dropify-->

<link href="/gledredes/assets/plugins/dropify/dropify.min.css" rel="stylesheet" type="text/css"/>




<!-- Bootstrap bundle JS -->
<script src="/gledredes/assets/js/bootstrap.bundle.min.js"></script>
<!--plugins-->
<script src="/gledredes/assets/js/jquery.min.js"></script>

<script src="/gledredes/assets/plugins/simplebar/js/simplebar.min.js"></script>
<script src="/gledredes/assets/plugins/metismenu/js/metisMenu.min.js"></script>
<script src="/gledredes/assets/js/pace.min.js"></script>

<!--app-->
<script src="/gledredes/assets/js/app.js"></script>
<script src="/gledredes/assets/js/index2.js"></script>

<script>
    //new PerfectScrollbar(".best-product");
</script>


<!--Datatables-->
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js" ></script>
<script src="https://cdn.datatables.net/buttons/1.6.5/js/dataTables.buttons.min.js" ></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js" ></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js" ></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js" ></script>
<script src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.html5.min.js" ></script>

<!--Select-->

<script src="/gledredes/assets/plugins/select2/js/select2.min.js"></script>
<script src="/gledredes/assets/js/form-select2.js"></script>




<!--Notificaciones-->
<script src="/gledredes/assets/plugins/notifications/js/lobibox.js"></script>
<script src="/gledredes/assets/plugins/notifications/js/notifications.min.js"></script>
<script src="/gledredes/assets/plugins/notifications/js/notification-custom-script.js"></script>

<!--Dropify-->
<script src="/gledredes/assets/plugins/dropify/dropify.min.js" type="text/javascript"></script>

<!--Utilitarios-->
<script src="/gledredes/js/utilitarios.js" type="text/javascript"></script>